import React from "react";

export const NotFound = () => {
  return <div>404 error sorry this page not found !!</div>;
};

export default NotFound;
