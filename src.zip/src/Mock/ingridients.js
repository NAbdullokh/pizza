import cheese from "../Assets/icon/generic/cheese.svg";
import cucumber from "../Assets/icon/generic/cucmber.svg";
import pepperoni from "../Assets/icon/generic/pepperoni.svg";
import sauce from "../Assets/icon/generic/sauce.svg";
import mushrooms from "../Assets/icon/generic/mushrooms.svg";
import onion from "../Assets/icon/generic/onion.svg";
import peper from "../Assets/icon/generic/peper.svg";

export const Ingridients = [
  { id: 21, title: "Моцарелла", img: cheese },
  { id: 25, title: "Огурцы", img: cucumber },
  { id: 37, title: "Пепперони", img: pepperoni },
  { id: 44, title: "Соус", img: sauce },
];

export default Ingridients;
